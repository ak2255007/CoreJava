// Java Program to Illustrate App File
package com.student;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
 
// Main class
public class App {
 
    // Main driver method
    public static void main(String[] args)
    {
 
        // Create Configuration
        Configuration configuration = new Configuration();
        configuration.configure("hibernate.cfg.xml");
        configuration.addAnnotatedClass(student.class);
 
        // Create Session Factory
        SessionFactory sessionFactory = configuration.buildSessionFactory();
 
        // Initialize Session Object
        Session session = sessionFactory.openSession();
 
        student student1 = new student();
 
        student1.setId(1);
        student1.setStudentsName("amit kumar");
        student1.setStudentscourse("java");
        
        student student2 = new student();
        
        student2.setId(2);
        student2.setStudentsName("sunil yadav");
        student2.setStudentscourse("java");
        
        student student3 = new student();
        
        student3.setId(3);
        student3.setStudentsName("vishal saini");
        student3.setStudentscourse("java");
        
        student student4 = new student();
        
        student4.setId(4);
        student4.setStudentsName("yogesh");
        student4.setStudentscourse("java");
 
        session.beginTransaction();
 
        // Here we have used
        // save() method of JPA
        session.save(student1);
        session.save(student2);
        session.save(student3);
        session.save(student4);
 
        session.getTransaction().commit();
    }
}
