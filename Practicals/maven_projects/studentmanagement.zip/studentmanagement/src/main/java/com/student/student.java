package com.student;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="student")
public class student {
	@Id 
    @Column(name = "student id")
    private int id;
 
    @Column(name = "student name")
    private String studentname ;
 
    @Column(name = "student course") 
    private String studentcourse;

	public int getId()
    { 
    	return id; 
    }
 
    public void setId(int id)
    { 
    	this.id = id;
    }
 
    public String getStudentname() 
    {
    	return studentname; 
    }
 
    public void setStudentsName(String studentname)
    {
    	this.studentname =studentname;
    }
 
    public String getStudentscourse() 
    { 
    	return studentcourse;
    }
 
    public void setStudentscourse(String studentcourse)
    {
    	this.studentcourse = studentcourse;
    }

}
